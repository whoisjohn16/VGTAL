package me.vilsol.betanpc.enums;

public enum SpawnStage {
	
	TYPE_CHOICE, RARITY_CHOICE, WEAPON_CHOICE;
	
}
