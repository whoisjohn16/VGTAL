package me.vilsol.itemgenerator.engine;

public enum ModifierType {
	
	RANGE, STATIC, TRIPLE;
	
}
