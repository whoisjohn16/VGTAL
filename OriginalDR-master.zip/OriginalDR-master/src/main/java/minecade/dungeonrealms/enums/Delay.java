package minecade.dungeonrealms.enums;

public enum Delay {
	
	MELEE(400);
	
	public int delay;
	
	private Delay(int delay) {
		this.delay = delay;
	}
	
}
