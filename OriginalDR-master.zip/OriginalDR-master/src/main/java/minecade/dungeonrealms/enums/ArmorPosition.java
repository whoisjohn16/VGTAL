package minecade.dungeonrealms.enums;

public enum ArmorPosition {
	
	HEAD, CHEST, LEGS, BOOTS
	
}
