package minecade.dungeonrealms.ModerationMechanics.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class CommandCheck implements CommandExecutor {
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		//Player p = null;
		//if(sender instanceof Player){
		//	p = (Player)sender;
		//}
		
		return true;
	}
	
}
